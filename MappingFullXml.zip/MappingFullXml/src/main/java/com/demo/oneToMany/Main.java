package com.demo.oneToMany;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import java.util.LinkedHashSet;
import java.util.Set;

public class Main {
    public static void main(String[] args) {
        SessionFactory sessionFactory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();

        Author author1 = new Author("Chetan Bhagat","chetanbhagat@gmail.com");
        Author author2 = new Author("Shashi Tharoor","shashitharoor@gmail.com");

        Book book1 = new Book("11 Rules for Life",550.55f);
        Book book2 = new Book("400 Days",650.90f);
        Book book3 = new Book("2 States",860.50f);
        Book book4 = new Book("The Great Indian Novel",460.50f);
        Book book5 = new Book("Why I Am a Hindu",790.00f);

        Set<Book> books1 = new LinkedHashSet<Book>();
        books1.add(book1);
        books1.add(book2);
        books1.add(book3);
        Set<Book> books2 = new LinkedHashSet<Book>();
        books2.add(book4);
        books2.add(book5);

        author1.setBooks(books1);
        author2.setBooks(books2);

        session.save(author1);
        session.save(author2);

        transaction.commit();
        session.close();
        System.out.println("done");
    }
}
