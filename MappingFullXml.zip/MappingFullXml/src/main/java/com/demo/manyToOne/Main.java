package com.demo.manyToOne;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main {
    public static void main(String[] args) {
        SessionFactory sessionFactory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();

        Department department1 = new Department();
        department1.setDeptName("Mechanical");
        Department department2 = new Department();
        department2.setDeptName("Computer Science");

        Teacher teacher1 = new Teacher();
        teacher1.setTeacherName("Ravish Patel");
        teacher1.setTeacherEmail("ravish@gmail.com");
        teacher1.setDepartment(department1);
        Teacher teacher2 = new Teacher();
        teacher2.setTeacherName("Vikas Jadhav");
        teacher2.setTeacherEmail("vikas@gmail.com");
        teacher2.setDepartment(department2);
        Teacher teacher3 = new Teacher();
        teacher3.setTeacherName("Shashi Shukla");
        teacher3.setTeacherEmail("Shashi@gmail.com");
        teacher3.setDepartment(department1);

        session.save(teacher1);
        session.save(teacher2);
        session.save(teacher3);

        transaction.commit();
        session.close();
        System.out.println("done");
    }
}
