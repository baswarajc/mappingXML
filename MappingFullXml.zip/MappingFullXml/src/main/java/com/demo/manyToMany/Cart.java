package com.demo.manyToMany;

import javax.persistence.SecondaryTable;
import java.util.Set;

public class Cart {
    private int cartId;
    private String cartPartner;
    private String cartType;
    private Set<Item> items;

    public Cart() {
    }

    public Cart(String cartPartner, String cartType) {
        this.cartPartner = cartPartner;
        this.cartType = cartType;
    }

    public int getCartId() {
        return cartId;
    }

    public void setCartId(int cartId) {
        this.cartId = cartId;
    }

    public String getCartPartner() {
        return cartPartner;
    }

    public void setCartPartner(String cartPartner) {
        this.cartPartner = cartPartner;
    }

    public String getCartType() {
        return cartType;
    }

    public void setCartType(String cartType) {
        this.cartType = cartType;
    }

    public Set<Item> getItems() {
        return items;
    }

    public void setItems(Set<Item> items) {
        this.items = items;
    }
}
