package com.demo.manyToMany;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

public class Main {
    public static void main(String[] args) {
        SessionFactory sessionFactory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();

        Item item1 = new Item("Vivo V7",10560.50f);
        Item item2 = new Item("OnePlus Bullet Z2",1300.50f);
        Item item3 = new Item("Firboalt Pro",1760.50f);
        Item item4 = new Item("Milton Bottle",755.25f);

        Cart cart1 = new Cart("ShadowFax","Prime");
        Cart cart2 = new Cart("Delivery","Normal");
        Cart cart3 = new Cart("Ecart","Prime");

        Set<Item> items1 = new LinkedHashSet<Item>();
        items1.add(item1);
        items1.add(item3);
        items1.add(item4);
        Set<Item> items2 = new LinkedHashSet<Item>();
        items2.add(item2);
        items2.add(item4);
        Set<Item> items3 = new LinkedHashSet<Item>();
        items3.add(item1);
        items3.add(item2);
        items3.add(item3);

        cart1.setItems(items1);
        cart2.setItems(items3);
        cart3.setItems(items2);

        session.save(cart1);
        session.save(cart2);
        session.save(cart3);

        transaction.commit();
        session.close();
        System.out.println("done");
    }
}
