package com.demo.oneToOne;

//import com.demo.oneToOne.Car;
//import com.demo.oneToOne.Owner;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main {
    public static void main(String[] args) {
        SessionFactory sessionFactory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();

        Owner owner1 = new Owner();
        owner1.setName("Vicky Sharma");
        owner1.setAddress("Lucknow");

        Owner owner2 = new Owner();
        owner2.setName("Vishwa Sharma");
        owner2.setAddress("Pune");

        Owner owner3 = new Owner();
        owner3.setName("Nilesh Pawar");
        owner3.setAddress("Indore");

        Car car1 = new Car();
        car1.setNo(5561);
        car1.setName("Nexon");
        car1.setCompany("Tata");

        Car car2 = new Car();
        car2.setNo(5562);
        car2.setName("Swift");
        car2.setCompany("Suzuki");

        Car car3 = new Car();
        car3.setNo(5563);
        car3.setName("Safari");
        car3.setCompany("Tata");

        owner1.setCar(car1);
        owner2.setCar(car2);
        owner3.setCar(car3);

        car1.setOwner(owner1);
        car2.setOwner(owner2);
        car3.setOwner(owner3);

        session.save(owner1);
        session.save(owner2);
        session.save(owner3);

        session.save(car1);
        session.save(car2);
        session.save(car3);

        transaction.commit();
        session.close();
        System.out.println("done");
    }
}